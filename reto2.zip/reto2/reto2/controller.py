import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from geometry_msgs.msg import Pose2D
from geometry_msgs.msg import Twist
import numpy as np


#Definición de la clase 
class Velocity(Node):
    #Constructor 
    def __init__(self):
        self.i = 0
        self.x = 0.0
        self.z = 0.0
        
        #Definición del tópico
        super().__init__('Azul_base_controller')
        
        #Definición del periodo de tiempo
        timer_period = 2.1

        #Creación del tópico publicador: Azul_Velocity
        self.publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        
        #Creación del tópico subcriptor: pose
        self.subscriber = self.create_subscription(Pose2D, 'pose', self.pose_callback, 10)

        #Timer para operaciones
        self.timer = self.create_timer(timer_period, self.timer_callback)

        #Confirmación de la creación del nodo
        self.get_logger().info('Controller node successfully initialized!!!')

        #Tipo de mensaje 
        self.msg = Float32()
    
    def pose_callback(self, msg):
        #Datos de pose recibidos
        self.x = float(msg.x.data)
        self.z = float(msg.y.data)
        self.get_logger().info(f'Received pose: x={msg.x}, y={msg.y}, theta={msg.theta}')

    #Método del timer
    def timer_callback(self):
        cmd_vel = Twist()
        
        self.x = float(self.x)
        self.z = float(self.z)

        cmd_vel.linear.x = float(self.x)

        cmd_vel.linear.y = 0.0
        cmd_vel.linear.z = 0.0

        cmd_vel.angular.x = 0.0
        cmd_vel.angular.y = 0.0

        cmd_vel.angular.z = float(self.z)
        self.publisher.publish(cmd_vel)

#Main Fnc
def main(args=None):
    #Inicialiation for rclpy 
    rclpy.init(args=args)
    #create node
    m_p = Velocity()
    #Spin method for publisher calback
    rclpy.spin(m_p)
    #Destoy node
    m_p.destroy_node()
    #rclpy shutdown
    rclpy.shutdown()

#main call method
if __name__ == 'main':    
    main()

'''
'''
