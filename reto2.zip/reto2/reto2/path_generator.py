import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from geometry_msgs.msg import Pose2D
import numpy as np


#Definición de la clase 
class Velocity(Node):
    #Constructor 
    def __init__(self):
        
        #Declaración de arreglos de trayectorias
        #Cuadrado
        self.c = 0
        self.pro = 0
        self.x = [0.21, 0.0, 0.21, 0.0, 0.21, 0.0, 0.21, 0.0]
        self.z = [0.0, .1379, 0.0, .1379, 0.0, .1379, 0.0, .1379]
        #Circulo
        self.x2 = [0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21]
        self.z2 = [0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21, 0.21]
        #Zigzag
        self.x3 = [0.21, 0.0, 0.21, 0.0, 0.21, 0.0, 0.21, 0.0]
        self.z3 = [0.0, .034, 0.0, -.034, 0.0, .034, 0.0, -.034]
        self.i = 0

        #Parámetros de tiempo y recorrido
        self.declare_parameter('type',0)
        self.declare_parameter('time',0) 
        
        #Definición del tópico
        super().__init__('Azul_path_generator')

        #Creación del tópico publicador: pose
        self.publisher = self.create_publisher(Pose2D, 'pose', 10)
        
        #Definición del periodo de tiempo
        timer_period = (self.get_parameter('time').get_parameter_value().integer_value) / 8
        self.pro = 4.3/timer_period

        #Timer para operaciones
        self.timer = self.create_timer(timer_period, self.timer_callback)

        #Confirmación de la creación del nodo
        self.get_logger().info('Path node successfully initialized!!!')

        #Tipo de mensaje 
        self.msg = Float32()

    #Método del timer
    def timer_callback(self):
        self.c = self.get_parameter('type').get_parameter_value().integer_value
        pose_msg = Pose2D()
        if self.c == 1:
            if self.i < 8:
                pose_msg.x = self.x[self.i] * self.pro

                pose_msg.y = self.z[self.i] * self.pro

            else:
                pose_msg.x = 0.0

                pose_msg.y = 0.0
        elif self.c == 2:
            if self.i < 8:
                pose_msg.x = self.x2[self.i] * self.pro

                pose_msg.y = self.z2[self.i] * self.pro

            else:
                pose_msg.x = 0.0

                pose_msg.y = 0.0
              
        elif self.c == 3:
            if self.i < 8:
                pose_msg.x = self.x3[self.i] * self.pro

                pose_msg.y = self.z3[self.i] * self.pro

            else:
                pose_msg.x = 0.0

                pose_msg.y = 0.0

        self.i = self.i + 1
        if pose_msg.x >= 0.8 or pose_msg.y >= 0.8:
            self.get_logger().info('Las velocidades superan las capacidades del robot. Poco tiempo de ejecucion')
        else:
            self.publisher.publish(pose_msg)

#Main Fnc
def main(args=None):
    #Inicialiation for rclpy 
    rclpy.init(args=args)
    #create node
    m_p = Velocity()
    #Spin method for publisher calback
    rclpy.spin(m_p)
    #Destoy node
    m_p.destroy_node()
    #rclpy shutdown
    rclpy.shutdown()

#main call method
if __name__ == 'main':    
    main()


