#import ros_actions for node
from launch_ros.actions import Node
#import launch description
from launch import LaunchDescription

#Generate launch description Fnc
def generate_launch_description():

    #launch node methd
    path_generator = Node(
        #Definition for node parameters 
        package='reto2',
        executable='path_generator',
        output='screen',
        parameters=[{'time': 0,
                     'type': 0,
                     }]#mandar parametros
    )

    controller = Node(
        #Definition for node parameters 
        package='reto2',
        executable='controller',
        output='screen',
    )
    
    #creates the launcher 
    ld = LaunchDescription([path_generator,controller])
    #return launcher
    return ld
